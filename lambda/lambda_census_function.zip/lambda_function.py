import re
import pandas as pd
import numpy as np
from census import Census
import census_tables_dict as d
import constants as constant
import json
import datetime
from io import BytesIO
from datetime import timedelta
# from datetime import datetime as dt
import boto3

s3_resource = boto3.resource('s3')


def get_datetime():
    dt = datetime.datetime.now()
    # dt = datetime.now()
    return dt.strftime("%Y%m%d"), dt.strftime("%H:%M:%S")


# Whether to return wide data (~830 rows, 340 columns) or long (~280k rows, 6 columns)
long = False

# FIXME: insert AWS account Census API key
# https://api.census.gov/data/key_signup.html
c = Census('a4642d28de30944a2e2c6c60bdc2f62559bcb14e')

###function for Error  SNS Notification#####
def send_error_sns(error_description, error_type, error_grouping_type, error_message):
    ssm = boto3.client("ssm", region_name="us-west-2")
    sns = boto3.client("sns", region_name="us-west-2")
    error_sns_arn = ssm.get_parameter(Name=constant.ERRORNOTIFICATIONARN)["Parameter"]["Value"]
    env = ssm.get_parameter(Name=constant.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    component_name = constant.COMPONENT_NAME
    sns_message = (f"{component_name} : {error_description} : {error_type} : {error_grouping_type} : {error_message}")
    err_response = sns.publish(
        TargetArn=error_sns_arn,
        Message=json.dumps({'default': json.dumps(sns_message)}),
        Subject=env + " : " + component_name,
        MessageStructure="json",
        MessageAttributes={
            "job_name": {"DataType": "String.Array",
                         "StringValue": 'Datalake-Extract-NOAA'}})
    return err_response

###function for Success notification####
def send_sns_success():
    sns = boto3.client("sns", region_name="us-west-2")
    ssm = boto3.client("ssm", region_name="us-west-2")
    success_sns_arn = ssm.get_parameter(Name=constant.SUCCESSNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    component_name = constant.COMPONENT_NAME
    env = ssm.get_parameter(Name=constant.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    success_msg = constant.SUCCESS_MSG
    sns_message = (f"{component_name} :  {success_msg}")
    print(sns_message, 'text')
    succ_response = sns.publish(
        TargetArn=success_sns_arn,
        Message=json.dumps({'default': json.dumps(sns_message)}),
        Subject=env + " : " + component_name,
        MessageStructure="json",
        MessageAttributes={
            "job_name": {
                "DataType": "String.Array",
                "StringValue": '["DATALAKE-Extract-CENSUS"]'}})
    

    return succ_response

#Function for getting  the census data from census api via generated key ###
def get_census_data(census_obj, long=long):
    # Define lists
    census_id = list()
    census_vars = list()
    human_readable = list()

    # Create mapping between Census tables and human-readable column names
    for i in d.tables.keys():
        cen_name = d.tables[i]['census_id']
        census_id.append(cen_name)

        census_vars = census_vars + \
                      [cen_name + '_' + variable + 'E' for variable in d.tables[i]['variables']] + \
                      [cen_name + '_' + variable + 'M' for variable in d.tables[i]['variables']]
        human_readable = human_readable + \
                         [name + 'E' for name in d.tables[i]['var_names']] + \
                         [name + 'M' for name in d.tables[i]['var_names']]

    # Request from Census API
    census_tup = tuple(['NAME'] + census_vars)
    census_df = pd.DataFrame(census_obj.acs5.state_county_tract(census_tup, '41', Census.ALL, Census.ALL))
    # print("key activated")

    # except APIKeyError:
    # send_error_sns()

    # Ensure column order
    census_df = census_df[['NAME', 'state', 'county', 'tract'] + census_vars]

    # Rename columns with human-readable names
    census_df.columns = ['name', 'state', 'county', 'tract'] + human_readable

    # Ensure ID columns are strings
    for i in ['state', 'county', 'tract']:
        census_df[i] = census_df[i].astype(int).astype(str)

    # Reformat to long structure, if desired
    if long:
        census_df = pd.melt(census_df,
                            id_vars=['name', 'state', 'county', 'tract'])

    # Create GEOID column to link to the service point mapping table
    census_df['GEOID'] = census_df.state + \
                         census_df.county.str.pad(width=3,
                                                  fillchar='0') + \
                         census_df.tract.str.pad(width=6,
                                                 fillchar='0')
    census_df['year'] = datetime.datetime.now().year - 2

    # print(census_df)
    return census_df

##function for generating new cols####
def transform_census_data(census):
    try:

        # Industry columns
        industry_cols = [i for i in census.columns if ('industry_' in i) and ('E' in i)]
        print(industry_cols, 'gotham')

        census['industry_total'] = census[industry_cols].sum(axis=1)

        for i in industry_cols:
            census['perc_' + i] = census[i] / census['industry_total']

        # Computing devices columns
        census['perc_hh_has_computing_devices'] = census.hh_has_computing_devicesE / (
                census.hh_has_computing_devicesE + census.hh_has_no_computerE)
        census['perc_hh_has_no_computing_devices'] = census.hh_has_no_computerE / (
                census.hh_has_computing_devicesE + census.hh_has_no_computerE)

        # Education columns
        educ_cols = [i for i in census.columns if ('educ_' in i) and ('E' in i)]
        census['educ_total'] = census[educ_cols].sum(axis=1)
        for i in educ_cols:
            census['perc_' + i] = census[i] / census['educ_total']

        # Labor force columns
        census['perc_pop_not_in_labor_force'] = census.pop_not_in_labor_forceE / census.pop_work_ageE
        census[
            'perc_pop_in_civ_labor_force_unemp'] = census.pop_in_civ_labor_force_unempE / census.pop_in_civ_labor_forceE

        # Household type columns
        census['perc_hh_type_family_married'] = census.hh_type_family_marriedE / census.hh_typeE
        census['perc_hh_type_single_parent'] = (
                                                       census.hh_type_family_other_single_dadE + census.hh_type_family_other_single_momE) / census.hh_typeE
        census['perc_hh_type_nonfamily_roommates'] = census.hh_type_nonfamily_roommatesE / census.hh_typeE
        census['perc_hh_type_nonfamily_bach'] = census.hh_type_nonfamily_bachE / census.hh_typeE

        # Rent cost columns
        rent_cols = ['hh_rent_10_perc_income',
                     'hh_rent_10to15_perc_income',
                     'hh_rent_15to20_perc_income',
                     'hh_rent_20to25_perc_income',
                     'hh_rent_25to30_perc_income',
                     'hh_rent_30to35_perc_income',
                     'hh_rent_35to40_perc_income',
                     'hh_rent_40to45_perc_income',
                     'hh_rent_45to50_perc_income',
                     'hh_rent_over50_perc_income']

        for i in rent_cols:
            census['perc_' + i] = census[i + 'E'] / census.hh_rentE

        # Health insurance columns
        census['perc_health_ins_private'] = (
                                                    census.num_per_native_health_ins_privateE + census.num_per_foreign_natur_health_ins_privateE + census.num_per_foreign_noncit_health_ins_privateE) / census.num_perE
        census['perc_health_ins_private'] = (
                                                    census.num_per_native_health_ins_publicE + census.num_per_foreign_natur_health_ins_publicE + census.num_per_foreign_noncit_health_ins_publicE) / census.num_perE
        census['perc_health_ins_private'] = (
                                                    census.num_per_native_no_health_insE + census.num_per_foreign_natur_no_health_insE + census.num_per_foreign_noncit_no_health_insE) / census.num_perE
        census['perc_native'] = census.num_per_nativeE / census.num_perE
        census['perc_foreign_natur'] = census.num_per_foreign_naturE / census.num_perE
        census['perc_foreign_noncit'] = census.num_per_foreign_noncitE / census.num_perE

        # Work transportation columns
        census['perc_work_transp_car'] = census.work_transp_carE / census.work_transpE
        census['perc_work_transp_public'] = census.work_transp_publicE / census.work_transpE

        # Number of household workers columns
        worker_cols = [i for i in census.columns if ('hh_workers_' in i) and ('E' in i)]
        census['hh_workers_total'] = census[worker_cols].sum(axis=1)
        for i in worker_cols:
            census['perc_' + i] = census[i] / census['hh_workers_total']

        # Occupation columns
        occup_cols = [i for i in census.columns if ('occup_' in i) and ('E' in i)]
        for i in occup_cols:
            census['perc' + i] = census[i] / census.occupE

        # Poverty level
        census['perc_poverty_lev_below'] = census.poverty_lev_belowE / census.poverty_levE

        # Received welfare
        census['perc_hh_welfare_received'] = census.hh_welfare_receivedE / census.hh_welfareE

        # Internet columns
        census['hh_internet_subscrip'] = census.hh_internet_subscripE / census.hh_internetE
        census['hh_internet_no_subscrip'] = census.hh_internet_no_subscripE / census.hh_internetE
        census['hh_internet_no_access'] = census.hh_internet_no_accessE / census.hh_internetE

        # Race columns
        race_cols = [i for i in census.columns if ('hh_race_' in i) and ('E' in i)]
        for i in race_cols:
            census['perc' + i] = census[i] / census.hh_raceE

        # Ratio of income to poverty level columns
        inc_to_pov_cols = [i for i in census.columns if ('hh_inc_to_pov_' in i) and ('E' in i)]
        census['hh_inc_to_pov_lev_total'] = census[inc_to_pov_cols].sum(axis=1)
        for i in inc_to_pov_cols:
            census['perc_' + i] = census[i] / census['hh_inc_to_pov_lev_total']

        # Adjust columns
        cen_cols = [i for i in census.columns if (('perc_' in i) and not ('_perc_' in i)) or (
                ('E' in i) and (('median' in i) or ('gini_' in i) or ('avg' in i)))]
        all_cols = ['name', 'state', 'county', 'tract', 'GEOID', 'year']
        all_cols.extend(cen_cols)
        census = census[all_cols]
        census.columns = [re.sub('E$', '', i) for i in census.columns]
    ####SUCCESS-SNS-NOTIFICATION ACTIVATED#####    
        send_sns_success()
        return census
    ####ERROR -SNS NOTIFICATION ACTIVATED#####
    except IndexError as index_error:
        send_error_sns("UNABLE_TRANF_FILE", "TECHNICAL_ERROR", "FILE_PROC_ERRORS", error_message=str(index_error))
    except Exception as e:
         send_error_sns("SYSTEM_ERRORS", "TECHNICAL_ERROR", "LAMBDA_ERRORS", error_message=str(e))
         
###BUCKETDETAILS FOR WRITING PARQUET FILES###
s3_bucket = "dsm-datalake-s3-bucket-dev"
s3_prefix = "Datalake_Raw/Census/Census_acs_5yr"
s3_prefix1 = "Datalake_Raw/Census/Census_acs_features"
datestr, timestr = get_datetime()
fname = f"CENSUS_ACS_5YR_{datestr}_{timestr}"
fname1 = f"CENSUS_ACS_FEATURES_{datestr}_{timestr}"
file_prefix = "/".join([s3_prefix, fname])
file_prefix1 = "/".join([s3_prefix1, fname1])


def lambda_handler(event, context):
    ####API ERROR EXCEPTION HANDLING####
    try:
        d = get_census_data(c)
    except Exception as e:
        Error_message=constant.ERROR_MSG
        send_error_sns("API KEY_ERRORS", "AUTH_ERROR", "API_ERRORS", error_message=Error_message)
    df1 = transform_census_data(d)
    # df1=df1.fillna(value=np.nan)
    print(type(df1))
    out_buffer = BytesIO()
    out_buffer1 = BytesIO()
    d.to_parquet(out_buffer)
    df1.to_parquet(out_buffer1)
    s3_resource.Object(s3_bucket, file_prefix).put(Body=out_buffer.getvalue())
    s3_resource.Object(s3_bucket, file_prefix1).put(Body=out_buffer1.getvalue())
    print("parquet files Written ")
        # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Success!')
    }
