import datetime 
def get_datetime():
    dt1 = datetime.datetime.now()
    return dt1.strftime("%d %B, %Y")
monthstr = get_datetime()
ERRORNOTIFICATIONARN = '/datalake/sns/errornotificationarn'
SUCCESSNOTIFICATIONARN='/datalake/sns/successnotificationarn'
COMPONENT_NAME = 'DL_LAMBDA_CENSUS_EXTRACT'
ERROR_MSG = f'NEED ATTENTION ****API ERROR /KEY EXPIRED ** ON {monthstr} ******'
SUCCESS_MSG = f'SUCCESSFULLY EXTRACTED CENSUS FILES FOR {monthstr}***'
SUCCESS_DESCRIPTION='SUCCESS'

ENVIRONMENT = '/matillion/environment'